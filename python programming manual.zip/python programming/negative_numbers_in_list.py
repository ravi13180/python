a=[-1,2,-3,4]
print([x for x in a if x<0])