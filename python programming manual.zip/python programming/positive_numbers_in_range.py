for i in range(-5,6):
    if i>0:print(i)