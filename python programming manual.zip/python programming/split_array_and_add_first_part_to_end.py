arr=[1,2,3,4,5]
pos=2
arr=arr[pos:]+arr[:pos]
print(arr)