arr=[1,2,3,4,5]
d=2
print(arr[d:]+arr[:d])