a=[2,3,4]
p=1
for i in a:p*=i
print(p)