a=[1,[],2,[],3]
a=[x for x in a if x!=[]]
print(a)