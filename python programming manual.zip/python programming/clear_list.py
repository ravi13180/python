a=[1,2,3]
a.clear()
print(a)