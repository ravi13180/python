a=[10,20,30,40]
i,j=1,3
a[i],a[j]=a[j],a[i]
print(a)