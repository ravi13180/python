a=[1,2,3]
b=a.copy()
print(b)