a=[4,2,7,1]
a.sort()
print(a[-2])