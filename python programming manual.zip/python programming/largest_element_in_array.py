arr=[1,7,3,9,5]
print(max(arr))