a=[4,2,7,1]
print(min(a))