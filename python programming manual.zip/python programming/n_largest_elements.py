import heapq
a=[4,2,7,1,9]
n=3
print(heapq.nlargest(n,a))