arr=[2,3,4]
n=5
p=1
for i in arr:p*=i
print(p%n)